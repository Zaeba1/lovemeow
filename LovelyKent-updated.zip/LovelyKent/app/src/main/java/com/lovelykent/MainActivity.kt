package com.lovelykent

import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.lovelykent.databinding.ActivityMainBinding
import com.lovelykent.ui.StoryController

class MainActivity : AppCompatActivity() {

    private lateinit var story: StoryController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        story = StoryController(this, binding) { finish() }

        // Back всегда работает: с любого экрана возвращает к началу, с первого — закрывает приложение.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!story.goBack()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        story.onStart()
    }

    override fun onStop() {
        story.onStop()
        super.onStop()
    }

    override fun onDestroy() {
        story.release()
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) story.onGlobalTouch(ev.rawX, ev.rawY)
        return super.dispatchTouchEvent(ev)
    }
}
